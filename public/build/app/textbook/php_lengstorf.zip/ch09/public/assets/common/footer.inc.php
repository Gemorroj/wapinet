    <script type="text/javascript"
          src="http://www.google.com/jsapi"></script>
    <script type="text/javascript">
        google.load("jquery", "1");
    </script>
    <script type="text/javascript"
          src="assets/js/valid-date.js"></script>
    <script type="text/javascript"
          src="assets/js/init.js"></script>
</body>

</html>