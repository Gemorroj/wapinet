DROP TABLE IF EXISTS author;
CREATE TABLE author (
  id INT,
  name TEXT
);
