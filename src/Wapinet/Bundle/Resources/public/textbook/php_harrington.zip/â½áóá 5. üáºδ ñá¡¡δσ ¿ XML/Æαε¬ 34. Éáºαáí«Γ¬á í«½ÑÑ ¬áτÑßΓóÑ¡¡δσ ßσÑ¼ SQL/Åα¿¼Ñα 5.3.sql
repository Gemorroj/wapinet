DROP TABLE IF EXISTS author;
CREATE TABLE author (
  id INT,
  name TEXT
);

DROP TABLE IF EXISTS book;
CREATE TABLE book (
  id INT,
  name TEXT,
  authors TEXT
);
