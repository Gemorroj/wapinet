DROP TABLE IF EXISTS author;
CREATE TABLE author (
  id INT NOT NULL AUTO_INCREMENT,
  name TEXT,
  PRIMARY KEY( id )
);

DROP TABLE IF EXISTS book;
CREATE TABLE book (
  id INT NOT NULL AUTO_INCREMENT,
  name TEXT,
  PRIMARY KEY( id )
);

DROP TABLE IF EXISTS book_author;
CREATE TABLE book_author (
  book_id INT,
  author_id INT
);
