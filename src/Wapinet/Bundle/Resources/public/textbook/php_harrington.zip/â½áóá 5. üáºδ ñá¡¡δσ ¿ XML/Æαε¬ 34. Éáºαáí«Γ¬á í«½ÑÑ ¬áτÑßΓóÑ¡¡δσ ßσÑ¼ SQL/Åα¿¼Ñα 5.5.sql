DROP TABLE IF EXISTS user;
CREATE TABLE user (
  id INT,
  first TEXT,
  last TEXT,
  username TEXT,
  password TEXT,
  description TEXT
);
