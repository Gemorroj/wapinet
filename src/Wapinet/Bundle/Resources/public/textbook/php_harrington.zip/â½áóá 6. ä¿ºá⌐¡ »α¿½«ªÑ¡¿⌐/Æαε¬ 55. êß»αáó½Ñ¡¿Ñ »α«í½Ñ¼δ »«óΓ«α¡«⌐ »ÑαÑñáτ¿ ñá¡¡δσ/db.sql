DROP TABLE IF EXISTS transcheck;
CREATE TABLE transcheck (
  transid TEXT,
  posted TIMESTAMP
);
