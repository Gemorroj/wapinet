INSERT INTO users VALUES ( 0, "jack", "toronto" );
INSERT INTO users VALUES ( 0, "megan", "omaha" );
